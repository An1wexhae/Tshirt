export interface Collection {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
}

export const collections: Collection[] = [
  {
    id: "1",
    name: "Hip-Hop Collection",
    slug: "hip-hop-collection",
    description: "Explore our exclusive Hip-Hop inspired oversized t-shirts featuring your favorite artists.",
    image: "/images/hero-travis.jpg",
  },
  {
    id: "2",
    name: "Bands Collection",
    slug: "bands-collection",
    description: "Find your favorite band's oversized t-shirts in our premium quality collection.",
    image: "/images/hero-culture.jpg",
  },
  {
    id: "3",
    name: "KANYE Collection",
    slug: "kanye-collection",
    description: "Ulrich, you can't tell me nothing",
    image: "/images/hero-kanye.jpg",
  },
  {
    id: "4",
    name: "The CULTURE",
    slug: "the-culture",
    description: "Premium quality t-shirts inspired by hip-hop culture.",
    image: "/images/hero-culture.jpg",
  }
];

export const getCollectionBySlug = (slug: string): Collection | undefined => {
  return collections.find(collection => collection.slug === slug);
};

export const getAllCollections = (): Collection[] => {
  return collections;
};
