export interface Product {
  id: string;
  name: string;
  slug: string;
  images: {
    front: string;
    back: string;
  };
  price: {
    original: number;
    discounted: number;
  };
  sizes: string[];
  colors: string[];
  materials: string[];
  description: string;
  details: string[];
  inStock: boolean;
  collection: string;
}

export const products: Product[] = [
  {
    id: "1",
    name: "Travis Scott Back Printed Oversized Tshirt",
    slug: "travis-scott-back-printed-oversized-tshirt",
    images: {
      front: "/images/products/travis-scott-front.jpg",
      back: "/images/products/travis-scott-back.jpg",
    },
    price: {
      original: 799,
      discounted: 369,
    },
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black"],
    materials: ["180 GSM Cotton"],
    description: "Travis Scott Back Printed Oversized Tshirt with premium quality cotton",
    details: [
      "Composition: 100% cotton",
      "GSM: 180",
      "Country of production: India",
      "Wash care: Machine wash cold with similar colours.",
      "Only non-chlorine.",
      "Tumble dry low.",
      "Warm Iron if needed."
    ],
    inStock: true,
    collection: "hip-hop",
  },
  {
    id: "2",
    name: "KANYE Oversized Tshirt",
    slug: "ye-oversized-tshirt",
    images: {
      front: "/images/products/kanye-front.jpg",
      back: "/images/products/kanye-back.jpg",
    },
    price: {
      original: 799,
      discounted: 369,
    },
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black"],
    materials: ["180 GSM Cotton"],
    description: "KANYE Oversized Tshirt with premium quality cotton",
    details: [
      "Composition: 100% cotton",
      "GSM: 180",
      "Country of production: India",
      "Wash care: Machine wash cold with similar colours.",
      "Only non-chlorine.",
      "Tumble dry low.",
      "Warm Iron if needed."
    ],
    inStock: true,
    collection: "hip-hop",
  },
  {
    id: "3",
    name: "Utopia Oversized Tshirt",
    slug: "utopia-oversized-tshirt",
    images: {
      front: "/images/products/travis-scott-front.jpg",
      back: "/images/products/utopia-back.jpg",
    },
    price: {
      original: 799,
      discounted: 379,
    },
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black"],
    materials: ["180 GSM Cotton"],
    description: "Utopia Oversized Tshirt with premium quality cotton",
    details: [
      "Composition: 100% cotton",
      "GSM: 180",
      "Country of production: India",
      "Wash care: Machine wash cold with similar colours.",
      "Only non-chlorine.",
      "Tumble dry low.",
      "Warm Iron if needed."
    ],
    inStock: true,
    collection: "hip-hop",
  },
  {
    id: "4",
    name: "Travis Scott Circus Maximus Oversized Tshirt",
    slug: "travis-scott-circus-maximus-oversized-tshirt",
    images: {
      front: "/images/products/travis-scott-front.jpg",
      back: "/images/products/travis-scott-back.jpg",
    },
    price: {
      original: 799,
      discounted: 489,
    },
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black"],
    materials: ["180 GSM Cotton"],
    description: "Travis Scott Circus Maximus Oversized Tshirt with premium quality cotton",
    details: [
      "Composition: 100% cotton",
      "GSM: 180",
      "Country of production: India",
      "Wash care: Machine wash cold with similar colours.",
      "Only non-chlorine.",
      "Tumble dry low.",
      "Warm Iron if needed."
    ],
    inStock: true,
    collection: "hip-hop",
  },
  {
    id: "5",
    name: "21 savage Oversized Tshirt",
    slug: "21-savage-oversized-tshirt",
    images: {
      front: "/images/products/travis-scott-front.jpg",
      back: "/images/products/travis-scott-back.jpg",
    },
    price: {
      original: 799,
      discounted: 439,
    },
    sizes: ["XS", "S", "M", "L", "XL"],
    colors: ["Black"],
    materials: ["180 GSM Cotton"],
    description: "21 savage Oversized Tshirt with premium quality cotton",
    details: [
      "Composition: 100% cotton",
      "GSM: 180",
      "Country of production: India",
      "Wash care: Machine wash cold with similar colours.",
      "Only non-chlorine.",
      "Tumble dry low.",
      "Warm Iron if needed."
    ],
    inStock: true,
    collection: "hip-hop",
  },
];

export const getProductBySlug = (slug: string): Product | undefined => {
  return products.find(product => product.slug === slug);
};

export const getProductsByCollection = (collection: string): Product[] => {
  return products.filter(product => product.collection === collection);
};

export const getAllProducts = (): Product[] => {
  return products;
};
