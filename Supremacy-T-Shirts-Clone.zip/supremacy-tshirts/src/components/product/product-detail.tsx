'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { ChevronDown, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Product, getAllProducts } from '@/lib/data/products';
import { useCart } from '@/lib/context/cart-context';
import ProductCard from './product-card';

interface ProductDetailProps {
  product: Product;
}

export default function ProductDetail({ product }: ProductDetailProps) {
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>(product.colors[0]);
  const [quantity, setQuantity] = useState<number>(1);
  const [activeImage, setActiveImage] = useState<'back' | 'front'>('back');
  const [isSizeChartOpen, setIsSizeChartOpen] = useState(false);

  const { addToCart } = useCart();
  const discount = Math.round(((product.price.original - product.price.discounted) / product.price.original) * 100);

  const similarProducts = getAllProducts()
    .filter(p => p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    if (!selectedSize) {
      alert('Please select a size');
      return;
    }

    addToCart(product, selectedSize, selectedColor, quantity);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="relative aspect-square overflow-hidden bg-neutral-100">
            <Image
              src={activeImage === 'back' ? product.images.back : product.images.front}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-cover"
              priority
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => setActiveImage('back')}
              className={`relative aspect-square overflow-hidden bg-neutral-100 ${
                activeImage === 'back' ? 'ring-2 ring-black' : ''
              }`}
            >
              <Image
                src={product.images.back}
                alt={`${product.name} - Back`}
                fill
                sizes="(max-width: 768px) 50vw, 25vw"
                className="object-cover"
              />
            </button>

            <button
              onClick={() => setActiveImage('front')}
              className={`relative aspect-square overflow-hidden bg-neutral-100 ${
                activeImage === 'front' ? 'ring-2 ring-black' : ''
              }`}
            >
              <Image
                src={product.images.front}
                alt={`${product.name} - Front`}
                fill
                sizes="(max-width: 768px) 50vw, 25vw"
                className="object-cover"
              />
            </button>
          </div>
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-2xl font-bold mb-2">{product.name}</h1>

          <div className="flex items-baseline space-x-3 mb-4">
            <span className="text-xl font-semibold">₹ {product.price.discounted}.00</span>
            {product.price.original > product.price.discounted && (
              <span className="text-gray-500 line-through">₹ {product.price.original}.00</span>
            )}
            {discount > 0 && (
              <span className="text-sm text-green-600">Save {discount}%</span>
            )}
          </div>

          {/* Size Selection */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <label className="text-sm font-medium">Size</label>
              <button
                onClick={() => setIsSizeChartOpen(!isSizeChartOpen)}
                className="text-sm flex items-center"
              >
                <span className="underline">Size Chart</span>
                <ChevronDown size={16} className="ml-1" />
              </button>
            </div>

            {isSizeChartOpen && (
              <div className="border p-4 mb-4 text-sm">
                <h4 className="font-medium mb-2">Oversized Tshirts</h4>
                <p className="mb-2">Use the size chart below to determine your size.</p>

                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="py-2 px-3 text-left">Size</th>
                        <th className="py-2 px-3 text-left">Chest (in)</th>
                        <th className="py-2 px-3 text-left">Length (in)</th>
                        <th className="py-2 px-3 text-left">Sleeve (in)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b">
                        <td className="py-2 px-3">XS</td>
                        <td className="py-2 px-3">41-42</td>
                        <td className="py-2 px-3">27</td>
                        <td className="py-2 px-3">8</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 px-3">S</td>
                        <td className="py-2 px-3">44</td>
                        <td className="py-2 px-3">28</td>
                        <td className="py-2 px-3">9</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 px-3">M</td>
                        <td className="py-2 px-3">45-46</td>
                        <td className="py-2 px-3">28-29</td>
                        <td className="py-2 px-3">9.5</td>
                      </tr>
                      <tr className="border-b">
                        <td className="py-2 px-3">L</td>
                        <td className="py-2 px-3">48</td>
                        <td className="py-2 px-3">30</td>
                        <td className="py-2 px-3">10</td>
                      </tr>
                      <tr>
                        <td className="py-2 px-3">XL</td>
                        <td className="py-2 px-3">49-50</td>
                        <td className="py-2 px-3">31</td>
                        <td className="py-2 px-3">11</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="grid grid-cols-5 gap-2">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`py-2 border text-sm ${
                    selectedSize === size
                      ? 'border-black bg-black text-white'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          {/* Color Selection */}
          <div className="mb-6">
            <label className="text-sm font-medium block mb-2">Color</label>
            <div className="flex space-x-2">
              {product.colors.map((color) => (
                <button
                  key={color}
                  onClick={() => setSelectedColor(color)}
                  className={`h-10 w-10 rounded-full border flex items-center justify-center ${
                    selectedColor === color ? 'border-black' : 'border-gray-300'
                  }`}
                >
                  <span className="sr-only">{color}</span>
                  <span
                    className="h-8 w-8 rounded-full bg-black"
                    aria-hidden="true"
                  />
                  {selectedColor === color && (
                    <Check size={16} className="absolute text-white" />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Material Selection */}
          <div className="mb-6">
            <label className="text-sm font-medium block mb-2">Material</label>
            <select
              className="w-full border border-gray-300 rounded-sm p-2 text-sm"
              value={product.materials[0]}
              disabled
            >
              {product.materials.map((material) => (
                <option key={material} value={material}>
                  {material}
                </option>
              ))}
            </select>
          </div>

          {/* Quantity Selection */}
          <div className="mb-8">
            <label className="text-sm font-medium block mb-2">Quantity</label>
            <div className="flex items-center border border-gray-300 w-32">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-3 py-1 border-r border-gray-300"
                disabled={quantity <= 1}
              >
                -
              </button>
              <span className="flex-1 text-center">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="px-3 py-1 border-l border-gray-300"
              >
                +
              </button>
            </div>
          </div>

          {/* Add to Cart Button */}
          <Button
            onClick={handleAddToCart}
            className="w-full mb-6"
            size="lg"
            disabled={!product.inStock}
          >
            {product.inStock ? 'Add to Cart' : 'Sold Out'}
          </Button>

          {/* Product Details */}
          <div className="border-t border-gray-200 pt-6">
            <h2 className="text-lg font-medium mb-4">PRODUCT DETAILS</h2>
            <ul className="space-y-2 text-sm">
              {product.details.map((detail, index) => (
                <li key={index} className="text-gray-700">{detail}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Similar Products */}
      <div className="border-t border-gray-200 pt-10">
        <h2 className="text-xl font-semibold mb-6">You may also like</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {similarProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
