'use client';

import { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Product } from '@/lib/data/products';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const { name, slug, images, price } = product;
  const discount = Math.round(((price.original - price.discounted) / price.original) * 100);

  return (
    <div className="group">
      <Link
        href={`/products/${slug}`}
        className="relative block aspect-square overflow-hidden bg-neutral-100"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <div className="relative w-full h-full transition-opacity duration-300">
          <Image
            src={isHovered ? images.front : images.back}
            alt={name}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </div>

        {discount > 0 && (
          <div className="absolute top-2 left-2 bg-black text-white text-xs px-2 py-1">
            Sale
          </div>
        )}
      </Link>

      <div className="mt-4">
        <Link href={`/products/${slug}`} className="block">
          <h3 className="text-sm font-medium mb-1 line-clamp-1">{name}</h3>
        </Link>

        <div className="flex items-center space-x-2">
          <span className="text-sm font-semibold">₹ {price.discounted}.00</span>
          {price.original > price.discounted && (
            <span className="text-sm text-gray-500 line-through">₹ {price.original}.00</span>
          )}
          {discount > 0 && (
            <span className="text-xs text-green-600">Save {discount}%</span>
          )}
        </div>
      </div>
    </div>
  );
}
