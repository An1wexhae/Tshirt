'use client';

import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetClose } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { useCart } from '@/lib/context/cart-context';
import Image from 'next/image';
import Link from 'next/link';
import { Minus, Plus, X } from 'lucide-react';

export default function CartDrawer() {
  const {
    cartItems,
    removeFromCart,
    updateQuantity,
    clearCart,
    cartTotal,
    isCartOpen,
    setIsCartOpen
  } = useCart();

  return (
    <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col">
        <SheetHeader className="border-b pb-4">
          <SheetTitle className="text-lg">Your Cart</SheetTitle>
        </SheetHeader>

        {cartItems.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6">
            <h3 className="text-lg font-medium mb-2">Your cart is empty</h3>
            <p className="text-gray-500 mb-6 text-center">
              Looks like you haven&apos;t added any items to your cart yet.
            </p>
            <SheetClose asChild>
              <Button variant="default" size="lg" asChild>
                <Link href="/">Continue Shopping</Link>
              </Button>
            </SheetClose>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            <div className="flex-1 overflow-y-auto py-4 space-y-4">
              {cartItems.map((item) => (
                <div key={`${item.productId}-${item.size}-${item.color}`} className="flex border-b pb-4">
                  <div className="w-24 h-24 relative rounded overflow-hidden mr-4">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="96px"
                    />
                  </div>

                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <h4 className="font-medium text-sm line-clamp-1">{item.name}</h4>
                      <button
                        onClick={() => removeFromCart(item.productId, item.size, item.color)}
                        className="text-gray-400 hover:text-gray-600"
                      >
                        <X size={16} />
                      </button>
                    </div>

                    <p className="text-gray-500 text-xs mb-1">Size: {item.size}</p>
                    <p className="text-gray-500 text-xs mb-3">Color: {item.color}</p>

                    <div className="flex justify-between items-center">
                      <div className="flex items-center border">
                        <button
                          onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity - 1)}
                          className="px-2 py-1 hover:bg-gray-100"
                          disabled={item.quantity <= 1}
                        >
                          <Minus size={14} />
                        </button>
                        <span className="px-3 text-sm">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity + 1)}
                          className="px-2 py-1 hover:bg-gray-100"
                        >
                          <Plus size={14} />
                        </button>
                      </div>
                      <p className="font-medium">₹ {item.price * item.quantity}.00</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t pt-4 pb-8 space-y-4">
              <div className="flex justify-between text-lg font-semibold">
                <span>Subtotal</span>
                <span>₹ {cartTotal}.00</span>
              </div>
              <p className="text-gray-500 text-xs">Shipping and taxes calculated at checkout</p>

              <div className="space-y-2">
                <Button className="w-full" size="lg" asChild>
                  <SheetClose asChild>
                    <Link href="/checkout">Checkout</Link>
                  </SheetClose>
                </Button>

                <SheetClose asChild>
                  <Button variant="outline" className="w-full" size="lg">
                    <Link href="/">Continue Shopping</Link>
                  </Button>
                </SheetClose>

                <Button
                  variant="link"
                  className="text-gray-500 text-sm underline w-full"
                  onClick={clearCart}
                >
                  Clear Cart
                </Button>
              </div>
            </div>
          </div>
        )}
      </SheetContent>
    </Sheet>
  );
}
