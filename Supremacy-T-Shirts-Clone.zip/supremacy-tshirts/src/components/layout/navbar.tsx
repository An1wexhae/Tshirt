'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Menu, Search, ShoppingBag, User, X } from 'lucide-react';
import { useCart } from '@/lib/context/cart-context';

export default function Navbar() {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const pathname = usePathname();
  const { cartCount, setIsCartOpen } = useCart();

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Hip-Hop Collection', href: '/collections/hip-hop-collection' },
    { name: 'Bands Collection', href: '/collections/bands-collection' },
    { name: 'Contact', href: '/contact' },
    { name: 'My Account', href: '/account' },
    { name: 'Exchange Policies', href: '/policies/exchange-policies' },
  ];

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle search submit
    console.log('Search for:', searchQuery);
  };

  return (
    <header className="relative">
      <div className="border-b border-gray-200">
        <div className="bg-neutral-50 py-2 text-center text-sm">
          Please receive the Order Confirmation Call after placing an order
        </div>
      </div>

      <nav className="container mx-auto p-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="relative h-12 w-40">
            <Image
              src="/images/logo.svg"
              alt="Supremacy Tshirts"
              fill
              sizes="(max-width: 768px) 100vw, 160px"
              priority
              className="object-contain"
            />
          </Link>

          {/* Desktop Navigation */}
          <ul className="hidden md:flex space-x-6">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className={`text-sm hover:text-primary ${pathname === link.href ? 'font-semibold' : ''}`}
                >
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            <button
              onClick={toggleSearch}
              className="hidden md:flex items-center"
              aria-label="Search"
            >
              {isSearchOpen ? <X size={20} /> : <Search size={20} />}
            </button>

            <Link href="/account" className="hidden md:flex" aria-label="My Account">
              <User size={20} />
            </Link>

            <button
              onClick={() => setIsCartOpen(true)}
              className="relative"
              aria-label="Cart"
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-white">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon" aria-label="Menu">
                  <Menu size={20} />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="sm:max-w-sm w-[80vw]">
                <nav className="flex flex-col mt-8 space-y-4">
                  {navLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      className="text-base hover:text-primary py-2"
                    >
                      {link.name}
                    </Link>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>

        {/* Search Bar */}
        {isSearchOpen && (
          <div className="absolute inset-x-0 top-full bg-white z-20 py-4 px-6 border-b border-gray-200">
            <form onSubmit={handleSearchSubmit} className="max-w-md mx-auto flex">
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-b-2 border-gray-300 focus:border-primary focus:outline-none py-2 px-4"
              />
              <button type="submit" className="ml-2">
                <Search size={20} />
              </button>
              <button type="button" onClick={toggleSearch} className="ml-2">
                <X size={20} />
              </button>
            </form>
          </div>
        )}
      </nav>
    </header>
  );
}
