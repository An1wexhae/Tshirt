'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Mail } from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle subscription logic
    console.log('Subscribe email:', email);
    setEmail('');
    // Show success message or notification
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-white border-t border-gray-200 mt-20">
      <div className="container mx-auto px-4 py-8">
        {/* Newsletter Subscription */}
        <div className="mb-10">
          <h3 className="text-lg font-medium mb-4">Subscribe to our emails</h3>
          <form onSubmit={handleSubscribe} className="max-w-md">
            <div className="flex">
              <div className="relative flex-1">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  required
                  className="w-full border-b border-gray-300 py-2 focus:outline-none focus:border-primary"
                />
                <Mail size={18} className="absolute right-3 top-2.5 text-gray-400" />
              </div>
              <button
                type="submit"
                className="ml-2 px-4 py-2 border border-black hover:bg-black hover:text-white transition-colors"
              >
                Subscribe
              </button>
            </div>
          </form>
        </div>

        {/* Payment Methods */}
        <div className="mb-6">
          <h3 className="text-sm font-medium mb-2">Payment methods</h3>
          <div className="flex space-x-2">
            {/* Payment icons would go here */}
          </div>
        </div>

        {/* Copyright and Links */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-t border-gray-200 pt-6">
          <div className="mb-4 md:mb-0">
            <p className="text-sm text-gray-500">
              © {currentYear},{' '}
              <Link href="/" className="hover:text-primary">
                supremacyclothing
              </Link>
            </p>
            <p className="text-xs text-gray-400 mt-1">
              Powered by{' '}
              <a
                href="https://www.shopify.com"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-primary"
              >
                Shopify
              </a>
            </p>
          </div>

          <ul className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-6">
            <li>
              <Link href="/policies/refund-policy" className="text-sm hover:text-primary">
                Refund policy
              </Link>
            </li>
            <li>
              <Link href="/policies/privacy-policy" className="text-sm hover:text-primary">
                Privacy policy
              </Link>
            </li>
            <li>
              <Link href="/policies/terms-of-service" className="text-sm hover:text-primary">
                Terms of service
              </Link>
            </li>
            <li>
              <Link href="/policies/contact-information" className="text-sm hover:text-primary">
                Contact information
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
