import { Metadata } from 'next';
import ContactForm from './contact-form';

export const metadata: Metadata = {
  title: 'Contact – supremacyclothing',
  description: 'Contact our customer service team for any questions or assistance.',
};

export default function ContactPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-12 text-center">Contact</h1>

      <div className="max-w-3xl mx-auto">
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Customer Service</h2>

          <p className="mb-4">Our availability timing:</p>
          <p className="mb-1">
            Everyday on call: <strong>9:00 AM - 6:00 PM</strong>
          </p>
          <p className="mb-4">
            Everyday on chat: <strong>9:00 AM - 6:00 PM</strong>
          </p>

          <p>
            Contact No.: <strong>6291862524</strong>
          </p>
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-6">Contact form</h2>
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
