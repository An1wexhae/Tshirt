import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { CheckCircle } from 'lucide-react';

export default function CheckoutSuccessPage() {
  return (
    <div className="container mx-auto px-4 py-16 text-center">
      <div className="max-w-md mx-auto">
        <div className="flex justify-center mb-6">
          <CheckCircle size={64} className="text-green-500" />
        </div>

        <h1 className="text-3xl font-bold mb-4">Order Placed Successfully!</h1>

        <p className="text-gray-600 mb-8">
          Thank you for your purchase. We have received your order and will process it shortly.
          You will receive a confirmation email with your order details.
        </p>

        <p className="text-sm text-gray-500 mb-6">
          Please receive the Order Confirmation Call after placing an order.
        </p>

        <div className="space-y-4">
          <Button asChild className="w-full">
            <Link href="/">Continue Shopping</Link>
          </Button>

          <Button variant="outline" asChild className="w-full">
            <Link href="/account">View My Orders</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
