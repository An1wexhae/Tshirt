import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getAllProducts } from '@/lib/data/products';
import ProductCard from '@/components/product/product-card';
import { Card, CardContent } from '@/components/ui/card';

export default function Home() {
  const products = getAllProducts();
  const travisScottProducts = products.filter(p => p.name.toLowerCase().includes('travis'));
  const featuredProducts = products.slice(0, 6);

  return (
    <div className="flex flex-col">
      {/* Hero Section - Travis Scott */}
      <section className="relative w-full h-[80vh] overflow-hidden">
        <Image
          src="/images/hero-travis.jpg"
          alt="Travis Scott Collection"
          fill
          priority
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-black/20 flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-xl text-white">
              <h1 className="text-5xl sm:text-7xl font-bold mb-6">TRAVIS SCOTT</h1>
              <p className="text-lg mb-8">
                Explore our exclusive Travis Scott inspired oversized t-shirts collection.
              </p>
              <Button asChild size="lg" className="bg-white text-black hover:bg-white/90">
                <Link href="/collections/hip-hop-collection">SHOP NOW</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Shop the Scotts Section */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-8">Shop the Scotts</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {travisScottProducts.slice(0, 3).map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* Kanye Section */}
      <section className="relative w-full h-[80vh] overflow-hidden">
        <Image
          src="/images/hero-kanye.jpg"
          alt="Kanye Collection"
          fill
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-black/20 flex items-center">
          <div className="container mx-auto px-4">
            <div className="ml-auto max-w-xl text-white">
              <h2 className="text-5xl sm:text-7xl font-bold mb-6">KANYE</h2>
              <p className="text-lg mb-8">
                Ulrich, you can&apos;t tell me nothing
              </p>
              <Button asChild size="lg" className="bg-white text-black hover:bg-white/90">
                <Link href="/collections/kanye-collection">SHOP NOW</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Kanye Collection Cards */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-8">KANYE Collection</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="overflow-hidden bg-neutral-100 relative h-[450px]">
            <CardContent className="p-0 h-full">
              <div className="relative h-full">
                <Image
                  src="/images/products/kanye-front.jpg"
                  alt="KANYE Full-Sleeves T-shirt"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
                <div className="absolute inset-0 flex flex-col justify-end p-8">
                  <h3 className="text-2xl font-bold mb-4">KANYE Full-Sleeves T-shirt</h3>
                  <Link
                    href="/products/ye-oversized-full-sleeves-t-shirt"
                    className="inline-flex items-center text-sm font-semibold hover:underline"
                  >
                    SHOP NOW <ArrowRight size={16} className="ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="overflow-hidden bg-neutral-100 relative h-[450px]">
            <CardContent className="p-0 h-full">
              <div className="relative h-full">
                <Image
                  src="/images/products/kanye-back.jpg"
                  alt="KANYE T-shirt"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 50vw"
                />
                <div className="absolute inset-0 flex flex-col justify-end p-8">
                  <h3 className="text-2xl font-bold mb-4">KANYE T-shirt</h3>
                  <Link
                    href="/products/ye-oversized-tshirt"
                    className="inline-flex items-center text-sm font-semibold hover:underline"
                  >
                    SHOP NOW <ArrowRight size={16} className="ml-1" />
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* The Culture Section */}
      <section className="relative w-full h-[60vh] overflow-hidden">
        <Image
          src="/images/hero-culture.jpg"
          alt="The CULTURE"
          fill
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-black/20 flex items-center">
          <div className="container mx-auto px-4">
            <div className="max-w-xl text-white">
              <h2 className="text-5xl sm:text-7xl font-bold mb-6">The CULTURE.</h2>
              <p className="text-lg mb-8">
                Premium quality t-shirts inspired by hip-hop culture.
              </p>
              <Button asChild size="lg" className="bg-white text-black hover:bg-white/90">
                <Link href="/collections/the-culture">EXPLORE</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 container mx-auto px-4">
        <h2 className="text-2xl font-semibold mb-8">The CULTURE.</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>
    </div>
  );
}
