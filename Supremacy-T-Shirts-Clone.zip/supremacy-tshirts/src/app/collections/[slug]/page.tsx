import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Image from 'next/image';
import { getCollectionBySlug, getAllCollections } from '@/lib/data/collections';
import { getProductsByCollection, getAllProducts } from '@/lib/data/products';
import ProductCard from '@/components/product/product-card';

interface CollectionPageProps {
  params: {
    slug: string;
  };
}

export async function generateMetadata({ params }: CollectionPageProps): Promise<Metadata> {
  const collection = getCollectionBySlug(params.slug);

  if (!collection) {
    return {
      title: 'Collection Not Found',
      description: 'The requested collection could not be found.'
    };
  }

  return {
    title: `${collection.name} – supremacyclothing`,
    description: collection.description,
  };
}

export function generateStaticParams() {
  const collections = getAllCollections();

  return collections.map((collection) => ({
    slug: collection.slug,
  }));
}

export default function CollectionPage({ params }: CollectionPageProps) {
  const collection = getCollectionBySlug(params.slug);

  if (!collection) {
    notFound();
  }

  // For demonstration purposes, if no products match the collection, show all products
  const productsByCollection = getProductsByCollection(collection.slug.split('-')[0]);
  const products = productsByCollection.length > 0 ? productsByCollection : getAllProducts();

  return (
    <div>
      {/* Collection Hero */}
      <div className="relative w-full h-[40vh] overflow-hidden">
        <Image
          src={collection.image}
          alt={collection.name}
          fill
          priority
          className="object-cover"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl sm:text-5xl font-bold text-white mb-4">
              {collection.name}
            </h1>
            <p className="text-white text-lg max-w-xl">
              {collection.description}
            </p>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-semibold">Products</h2>
          <div className="flex space-x-2">
            <span className="text-sm text-gray-500">
              {products.length} products
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
