'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Minus, Plus, Trash2 } from 'lucide-react';
import { useCart } from '@/lib/context/cart-context';

export default function CartPage() {
  const { cartItems, removeFromCart, updateQuantity, cartTotal } = useCart();

  // Check if the cart is empty
  if (cartItems.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-6">Your Cart</h1>
        <p className="text-gray-500 mb-8">Your cart is currently empty.</p>
        <Button asChild>
          <Link href="/">Continue Shopping</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">Your Cart</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="md:col-span-2 space-y-6">
          {/* Cart Header (Desktop) */}
          <div className="hidden md:grid grid-cols-12 gap-4 pb-2 border-b text-sm font-medium">
            <div className="col-span-6">Product</div>
            <div className="col-span-2 text-center">Price</div>
            <div className="col-span-2 text-center">Quantity</div>
            <div className="col-span-2 text-center">Total</div>
          </div>

          {/* Cart Items */}
          {cartItems.map((item) => (
            <div
              key={`${item.productId}-${item.size}-${item.color}`}
              className="grid grid-cols-1 md:grid-cols-12 gap-4 border-b pb-6"
            >
              {/* Product Image & Info */}
              <div className="md:col-span-6 flex">
                <div className="w-20 h-20 relative rounded overflow-hidden mr-4">
                  <Image
                    src={item.image}
                    alt={item.name}
                    fill
                    sizes="80px"
                    className="object-cover"
                  />
                </div>

                <div>
                  <h3 className="font-medium mb-1">{item.name}</h3>
                  <p className="text-sm text-gray-500 mb-1">Size: {item.size}</p>
                  <p className="text-sm text-gray-500 mb-2">Color: {item.color}</p>

                  <button
                    onClick={() => removeFromCart(item.productId, item.size, item.color)}
                    className="text-sm text-gray-500 hover:text-gray-700 flex items-center md:hidden"
                  >
                    <Trash2 size={14} className="mr-1" /> Remove
                  </button>
                </div>
              </div>

              {/* Price */}
              <div className="md:col-span-2 flex items-center md:justify-center">
                <span className="text-sm md:hidden mr-2">Price:</span>
                <span>₹ {item.price}.00</span>
              </div>

              {/* Quantity */}
              <div className="md:col-span-2 flex items-center md:justify-center">
                <span className="text-sm md:hidden mr-2">Quantity:</span>
                <div className="flex items-center border">
                  <button
                    onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity - 1)}
                    className="px-2 py-1 hover:bg-gray-100"
                    disabled={item.quantity <= 1}
                  >
                    <Minus size={14} />
                  </button>
                  <span className="px-3 text-sm">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.productId, item.size, item.color, item.quantity + 1)}
                    className="px-2 py-1 hover:bg-gray-100"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </div>

              {/* Total */}
              <div className="md:col-span-2 flex items-center justify-between md:justify-center">
                <span className="text-sm md:hidden">Total:</span>
                <span className="font-medium">₹ {item.price * item.quantity}.00</span>

                <button
                  onClick={() => removeFromCart(item.productId, item.size, item.color)}
                  className="text-gray-500 hover:text-gray-700 hidden md:flex"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="md:col-span-1">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h2 className="text-xl font-semibold mb-4">Order Summary</h2>

            <div className="space-y-3 mb-4">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>₹ {cartTotal}.00</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Shipping</span>
                <span>Calculated at checkout</span>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-3 mb-6">
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span>₹ {cartTotal}.00</span>
              </div>
            </div>

            <Button className="w-full mb-3" asChild>
              <Link href="/checkout">Proceed to Checkout</Link>
            </Button>

            <Button variant="outline" className="w-full" asChild>
              <Link href="/">Continue Shopping</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
