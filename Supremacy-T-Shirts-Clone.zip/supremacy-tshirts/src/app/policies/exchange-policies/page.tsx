import { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Exchange Policies – supremacyclothing',
  description: 'Our exchange policies for returns and shipping information.',
};

export default function ExchangePoliciesPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-12 text-center">Exchange Policies</h1>

      <div className="max-w-3xl mx-auto space-y-8">
        {/* Shipping & Tracking Section */}
        <section>
          <h2 className="text-2xl font-semibold mb-4">Shipping & Tracking</h2>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium mb-2">When will you ship my order?</h3>
              <p>
                All the orders, once shipped, are typically delivered in 1-4 working days in metros,
                and 4-7 working days for the rest of India. Delivery time may vary depending upon the shipping address.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">How can I Track my order?</h3>
              <p>
                You can track your order once it has been shipped from our warehouse.
                An email and SMS will be sent with a link.
              </p>
            </div>
          </div>
        </section>

        {/* Exchanges Section */}
        <section>
          <h2 className="text-2xl font-semibold mb-4">EXCHANGES</h2>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium mb-2">What is your return policy?</h3>
              <p className="mb-2">
                There is no Return Policy; Client can Exchange any product
              </p>
              <p className="font-medium">Rate for Exchange:</p>
              <ul className="list-disc list-inside pl-4 space-y-1">
                <li>100 for 1 product</li>
                <li>120 for 2 products</li>
                <li>140 for 3 and more products</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">How do I initiate an Exchange?</h3>
              <p className="mb-2">
                Please mail us at <a href="mailto:exchangesupremacy@gmail.com" className="text-primary underline">
                  exchangesupremacy@gmail.com
                </a> to initiate an exchange. Please mention the following information clearly in the mail:
              </p>
              <ul className="list-disc list-inside pl-4 space-y-1">
                <li>Order Number / Registered E-Mail Id</li>
                <li>Exchange Requirement.</li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-2">Do you arrange for reverse pickups?</h3>
              <p>
                We have a reverse pick up facility for most pin codes, In case we don't have the reverse pickup
                available at your location you would have to send the product back to us for exchange at the
                below-mentioned address.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
